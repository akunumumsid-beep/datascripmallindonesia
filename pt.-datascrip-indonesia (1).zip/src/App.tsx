/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProductCatalog from './components/ProductCatalog';
import CartDrawer from './components/CartDrawer';
import ShipmentTracker from './components/ShipmentTracker';
import AccountManagement from './components/AccountManagement';
import WhatsappWidget from './components/WhatsappWidget';
import { Product, CartItem, CustomerProfile, Order, COMPANY_PROFILE } from './types';
import { Mail, MapPin, Phone, ShieldCheck, FileCheck, ExternalLink, Calendar, Landmark } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('catalog');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentUser, setCurrentUser] = useState<CustomerProfile | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [selectedTrackingId, setSelectedTrackingId] = useState<string>('');

  // Hydrate states from localStorage for durable persistence
  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('datascrip_user');
      if (storedUser) {
        setCurrentUser(JSON.parse(storedUser));
      }

      const storedCart = localStorage.getItem('datascrip_cart');
      if (storedCart) {
        setCart(JSON.parse(storedCart));
      }

      const storedOrders = localStorage.getItem('datascrip_orders');
      if (storedOrders) {
        setOrders(JSON.parse(storedOrders));
      }
    } catch (e) {
      console.error('Error loading data from localStorage', e);
    }
  }, []);

  // Save changes to localStorage synchronously
  const saveUserToStorage = (user: CustomerProfile | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem('datascrip_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('datascrip_user');
    }
  };

  const saveCartToStorage = (updatedCart: CartItem[]) => {
    setCart(updatedCart);
    localStorage.setItem('datascrip_cart', JSON.stringify(updatedCart));
  };

  const saveOrdersToStorage = (updatedOrders: Order[]) => {
    setOrders(updatedOrders);
    localStorage.setItem('datascrip_orders', JSON.stringify(updatedOrders));
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity: number) => {
    const existingIndex = cart.findIndex((item) => item.product.id === product.id);
    let updatedCart = [...cart];
    if (existingIndex > -1) {
      updatedCart[existingIndex].quantity += quantity;
    } else {
      updatedCart.push({ product, quantity });
    }
    saveCartToStorage(updatedCart);
  };

  const handleUpdateCartQty = (productId: string, val: number) => {
    const updatedCart = cart.map((item) => {
      if (item.product.id === productId) {
        const newQty = Math.max(1, item.quantity + val);
        return { ...item, quantity: newQty };
      }
      return item;
    });
    saveCartToStorage(updatedCart);
  };

  const handleRemoveCartItem = (productId: string) => {
    const updatedCart = cart.filter((item) => item.product.id !== productId);
    saveCartToStorage(updatedCart);
  };

  // Complete checkout callback
  const handleCompleteCheckout = (newOrder: Order) => {
    const updatedOrders = [newOrder, ...orders];
    saveOrdersToStorage(updatedOrders);
    setCart([]); // Clear cart
    localStorage.removeItem('datascrip_cart');
  };

  const handleLogout = () => {
    saveUserToStorage(null);
  };

  const handleLogin = (profile: CustomerProfile) => {
    saveUserToStorage(profile);
  };

  const handleUpdateProfile = (profile: CustomerProfile) => {
    saveUserToStorage(profile);
  };

  const handleNavigateToTracker = (orderId: string) => {
    setSelectedTrackingId(orderId);
    setActiveTab('tracking');
  };

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartTotal = cart.reduce((acc, item) => acc + (item.product.pricePerUnit * item.quantity), 0);

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(num);
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans">
      
      {/* Header Portal Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          // clear tracking parameter if user manually shifts tab
          if (tab !== 'tracking') setSelectedTrackingId('');
        }}
        cartCount={cartCount}
        cartTotal={cartTotal}
        currentUser={currentUser}
        onOpenCart={() => setIsCartOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main Container Wrapper */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Tab Route Renderers */}
        {activeTab === 'catalog' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <Hero
              onExploreCatalog={() => {
                const el = document.getElementById('product-grid');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              onTrackOrder={() => setActiveTab('tracking')}
            />
            
            <div className="border-b border-slate-200 pb-3 flex justify-between items-end text-left font-sans">
              <div>
                <span className="text-[10px] bg-blue-50 text-blue-700 font-extrabold px-2.5 py-1 rounded uppercase tracking-wider font-mono">
                  Sinar Dunia • e-Paper • PaperOne
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight mt-1">
                  Katalog Pemesanan Kertas HVS & Buku
                </h2>
                <p className="text-xs text-slate-500">
                  Pilih gramatur tebal kertas A4 / F4 harian atau buku tulis bergaris sekolah.
                </p>
              </div>
            </div>

            <ProductCatalog onAddToCart={handleAddToCart} />
          </div>
        )}

        {activeTab === 'tracking' && (
          <div className="space-y-6 animate-in fade-in duration-200 text-left">
            <div className="border-b border-slate-200 pb-3">
              <span className="text-[10px] bg-blue-50 text-blue-700 font-extrabold px-2.5 py-1 rounded uppercase tracking-wider font-mono">
                Logistik Terintegrasi Batam
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight mt-1">
                Lacak No. Invoice Pengiriman
              </h2>
              <p className="text-xs text-slate-500">
                Pantau langsung pergerakan armada pengirim kertas dari PT. Datascrip.
              </p>
            </div>

            <ShipmentTracker
              orders={orders}
              defaultSearchId={selectedTrackingId}
            />
          </div>
        )}

        {activeTab === 'account' && (
          <div className="space-y-6 animate-in fade-in duration-205 text-left">
            <div className="border-b border-slate-200 pb-3">
              <span className="text-[10px] bg-blue-50 text-blue-700 font-extrabold px-2.5 py-1 rounded uppercase tracking-wider font-mono">
                Sistem Akun Multi-Order
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight mt-1">
                Manajemen Akun Pelanggan
              </h2>
              <p className="text-xs text-slate-500">
                Pembaruan alamat kirim otomatis dan arsip riwayat tagihan di Batam.
              </p>
            </div>

            <AccountManagement
              currentUser={currentUser}
              onLogin={handleLogin}
              onLogout={handleLogout}
              onUpdateProfile={handleUpdateProfile}
              orderHistory={orders}
              onTrackOrder={handleNavigateToTracker}
            />
          </div>
        )}

        {activeTab === 'profile' && (
          /* Specialized Tab: Rich Profile PT. Datascrip Indonesia information */
          <div className="max-w-4xl mx-auto bg-white rounded-3xl border border-slate-200 p-8 shadow-sm space-y-8 text-left animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-5 border-b border-slate-200">
              <div>
                <span className="text-[10px] bg-blue-700 text-white font-bold px-2.5 py-1 rounded uppercase tracking-widest font-mono">
                  Distributor Resmi
                </span>
                <h2 className="text-2xl font-black text-slate-800 tracking-tight mt-2 uppercase">
                  PT. DATASCRIP INDONESIA
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  Cabang Utama Distribusi Kertas & ATK Kota Batam, Kepulauan Riau
                </p>
              </div>
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs shrink-0 font-mono">
                <strong>Jam Administrasi:</strong><br />
                Senin - Sabtu: 08.00 - 17.00 WIB
              </div>
            </div>

            {/* Core credentials layout block */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-700">
              <div className="space-y-4">
                <h4 className="text-sm font-black text-slate-800 uppercase tracking-wide flex items-center gap-2">
                  <MapPin className="w-4.5 h-4.5 text-blue-700" />
                  Alamat Kantor & Gudang Distribusi:
                </h4>
                <p className="bg-slate-50 p-4 rounded-xl border border-slate-200 leading-relaxed font-sans text-slate-600">
                  <strong>PT. Datascrip Indonesia Cabang Batam</strong><br />
                  Ruko Komp. Batam Center, Blok D No. 4, Kel. Teluk Tering, Kec. Batam Kota, Kota Batam, Kepulauan Riau (29461), Indonesia.
                </p>

                <div className="space-y-3">
                  <h4 className="text-sm font-black text-slate-800 uppercase tracking-wide flex items-center gap-2">
                    <Mail className="w-4.5 h-4.5 text-blue-700" />
                    Kontak Representatif Resmi:
                  </h4>
                  <div className="space-y-2 bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Email Bisnis:</span>
                      <a href={`mailto:${COMPANY_PROFILE.email}`} className="font-bold text-blue-700 hover:underline">
                        {COMPANY_PROFILE.email}
                      </a>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">WhatsApp Hub:</span>
                      <a href={`https://wa.me/${COMPANY_PROFILE.whatsapp.replace(/[^0-9]/g, '')}`} className="font-bold text-emerald-600 hover:underline">
                        {COMPANY_PROFILE.whatsapp}
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Financial & Banking block */}
              <div className="space-y-4">
                <h4 className="text-sm font-black text-slate-800 uppercase tracking-wide flex items-center gap-2">
                  <Landmark className="w-4.5 h-4.5 text-blue-700" />
                  Informasi Pembayaran / No. Rekening:
                </h4>
                
                <div className="bg-slate-900 text-white rounded-2xl p-4.5 space-y-3.5 border border-slate-800">
                  <div className="flex justify-between items-baseline border-b border-white/10 pb-2">
                    <span className="text-slate-400">Bank Pengiriman:</span>
                    <span className="font-bold text-blue-300 text-sm">BANK OCBC INDONESIA</span>
                  </div>

                  <div className="flex justify-between items-baseline">
                    <span className="text-slate-400">Atas Nama Penerima:</span>
                    <span className="font-black text-slate-100 uppercase tracking-tight text-right">
                      {COMPANY_PROFILE.bankAccount.accountHolder}
                    </span>
                  </div>

                  <div className="bg-white/5 p-3 rounded-xl border border-white/10 text-center">
                    <span className="text-[10px] text-slate-400 block mb-0.5 uppercase font-mono font-bold tracking-wider">NOMOR REKENING OCBC</span>
                    <span className="text-base font-extrabold text-blue-300 font-mono tracking-widest block">
                      {COMPANY_PROFILE.bankAccount.accountNumber}
                    </span>
                  </div>
                </div>

                <div className="space-y-1 bg-amber-50 p-3.5 rounded-xl border border-amber-100 text-[11px] leading-relaxed text-amber-800">
                  <span className="font-bold block">🚨 Informasi Penting Pembayaran:</span>
                  <p className="text-amber-700">
                    Kami meminta seluruh pelanggan setuju mentransfer nominal yang tertera persis ke rekening OCBC di atas sebelum diverifikasi oleh kasir logistik. Terima kasih atas pengertiannya.
                  </p>
                </div>
              </div>
            </div>

            {/* Quality Seals */}
            <div className="pt-6 border-t border-slate-200 text-xs">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-3 text-center">
                Komitmen Mutu PT. Datascrip Indonesia Cabang Batam:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-start gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Teknologi Cetak TRUTONE</span>
                    <p className="text-[11px] text-slate-500 mt-0.5">Memastikan penyerapan tinta prima, kontras tinggi, cetakan hitam pekat bebas buram pada merek Sinar Dunia.</p>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <FileCheck className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-800">Serat Kertas High Whiteness</span>
                    <p className="text-[11px] text-slate-500 mt-0.5">Ideal untuk photocopy berkecepatan tinggi tanpa hambatan (jam-free guarantee) pada PaperOne & e-Paper.</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* Floating interactive cart modal drawer popup */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQty={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
        currentUser={currentUser}
        onCompleteCheckout={handleCompleteCheckout}
      />

      {/* Global Sticky WhatsApp administrator chat widget */}
      <WhatsappWidget />

      {/* Corporate Professional Clean Footer */}
      <footer className="bg-slate-900 text-white py-12 border-t border-slate-800 font-sans mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-left">
            
            {/* Box 1: Brand details */}
            <div className="space-y-4 md:col-span-2">
              <div className="flex items-center gap-3">
                <svg viewBox="0 0 100 100" className="w-9 h-9" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="6" y="6" width="88" height="88" stroke="#3b82f6" strokeWidth="6" rx="4" fill="none" />
                  <rect x="12" y="50" width="16" height="38" fill="#3b82f6" />
                  <rect x="34" y="12" width="16" height="76" fill="#3b82f6" />
                  <polygon points="56,12 88,12 88,44" fill="#3b82f6" />
                  <polygon points="56,88 88,88 88,56" fill="#3b82f6" />
                </svg>
                <div>
                  <h4 className="text-sm font-black uppercase tracking-tight text-slate-100">
                    PT. DATASCRIP INDONESIA
                  </h4>
                  <span className="text-[9px] font-mono tracking-widest text-slate-400">DISTRIBUTOR RESMI BATAM REPUBLIK INDONESIA</span>
                </div>
              </div>
              <p className="text-xs text-slate-400 max-w-md leading-relaxed font-sans">
                PT. Datascrip Indonesia Kantor Cabang Batam merupakan pusat distribusi utama penyuplai kertas photocopy premium, HVS A4 & F4, dan buku tulis sekolah merek Sinar Dunia (SiDU), e-Paper, dan Paper One untuk wilayah Kepulauan Riau.
              </p>
              <div className="text-[10px] text-slate-400">
                Penerimaan Pembayaran Bank OCBC: <strong className="text-blue-400 font-mono">9408 1006 3823</strong> (A.N. SALMI AIDI ANASTY)
              </div>
            </div>

            {/* Box 2: Quick Links */}
            <div className="space-y-3">
              <h4 className="text-xs font-black uppercase text-slate-400 tracking-widest">Akses Portal</h4>
              <ul className="text-xs text-slate-300 space-y-2 font-medium">
                <li>
                  <button onClick={() => setActiveTab('catalog')} className="hover:text-blue-400 transition-colors cursor-pointer">
                    Katalog & Pemesanan HVS
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('tracking')} className="hover:text-blue-400 transition-colors cursor-pointer">
                    Sistem Pelacakan Pengiriman
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('account')} className="hover:text-blue-400 transition-colors cursor-pointer">
                    Manajemen Profil Pelanggan
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('profile')} className="hover:text-blue-400 transition-colors cursor-pointer">
                    Profil Hub Distribusi Batam
                  </button>
                </li>
              </ul>
            </div>

            {/* Box 3: Contact & Legal */}
            <div className="space-y-3 text-xs">
              <h4 className="text-xs font-black uppercase text-slate-400 tracking-widest">Kontak Support</h4>
              <div className="space-y-2 text-slate-300">
                <p className="flex items-center gap-1.5 font-mono">
                  <Phone className="w-4 h-4 text-emerald-400 inline shrink-0" />
                  0851-6599-0362
                </p>
                <p className="flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-blue-400 inline shrink-0" />
                  datascripindonesia@gmail.com
                </p>
                <p className="text-[10px] text-slate-500 leading-snug">
                  PT. Datascrip Indonesia Cabang Batam, Kepulauan Riau.
                </p>
              </div>
            </div>

          </div>

          <div className="mt-8 pt-8 border-t border-slate-800 flex flex-col sm:flex-row justify-between text-[11px] text-slate-500 text-left font-serif">
            <span className="font-sans">
              © 2026 PT. DATASCRIP INDONESIA. Hak Cipta Dilindungi Undang-Undang.
            </span>
            <span className="font-mono text-slate-600">
              Coded & Managed in Batam, Kepulauan Riau
            </span>
          </div>
        </div>
      </footer>

    </div>
  );
}
