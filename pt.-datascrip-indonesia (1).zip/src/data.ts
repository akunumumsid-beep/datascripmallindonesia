import { Product, Order } from './types';

export const BATAM_DISTRICTS = [
  'Batam Kota',
  'Lubuk Baja (Nagoya)',
  'Batu Ampar',
  'Sekupang',
  'Nongsa',
  'Bengkong',
  'Batu Aji',
  'Sagulung',
  'Sei Beduk',
  'Belakang Padang',
  'Bulang',
  'Galang'
];

export const PRODUCTS: Product[] = [
  {
    id: 'P001',
    name: 'Kertas HVS PaperOne Premium A4 80gsm',
    brand: 'PaperOne',
    size: 'A4',
    weight: '80 gsm',
    priceText: 'Rp 295.000',
    pricePerUnit: 295000,
    unitType: 'Karton (5 Rim)',
    stock: 2450,
    description: 'Kertas photocopy premium dengan teknologi ProDigi HD Print Technology. Memiliki tingkat keputihan tinggi (167 CIE) dan ketebalan prima 80gsm, sangat ideal untuk cetak dua sisi (duplex) tanpa bayangan. Dilengkapi perlindungan serat anti jam.',
    imageUrl: '/assets/images/regenerated_image_1780228015061.jpg',
    featured: true,
    rating: 4.9,
    reviewsCount: 382
  },
  {
    id: 'P002',
    name: 'Kertas HVS PaperOne Multipurpose F4 70gsm',
    brand: 'PaperOne',
    size: 'F4',
    weight: '70 gsm',
    priceText: 'Rp 280.000',
    pricePerUnit: 280000,
    unitType: 'Karton (5 Rim)',
    stock: 1850,
    description: 'Kertas HVS ukuran F4 (Folio) 70gsm, dirancang khusus untuk kebutuhan cetak massal, fotokopi kantor, dokumen legal, dan aktivitas administrasi. Sangat hemat, anti macet (jam-free), dan menghasilkan teks yang tajam.',
    imageUrl: '/assets/images/regenerated_image_1780228016871.webp',
    featured: true,
    rating: 4.8,
    reviewsCount: 216
  },
  {
    id: 'P003',
    name: 'Kertas HVS Sinar Dunia (SiDU) A4 70gsm',
    brand: 'Sinar Dunia',
    size: 'A4',
    weight: '70 gsm',
    priceText: 'Rp 245.000',
    pricePerUnit: 245000,
    unitType: 'Karton (5 Rim)',
    stock: 5210,
    description: 'Merk legendaris Sinar Dunia (SiDU). Kertas A4 berkualitas tinggi dengan ketebalan standar 70gsm. Sangat baik untuk kebutuhan sekolah, perkantoran, dan cetak tugas harian. Teknologi serat padat menghasilkan performa cetak prima.',
    imageUrl: '/assets/images/regenerated_image_1780228017959.webp',
    featured: true,
    rating: 4.9,
    reviewsCount: 540
  },
  {
    id: 'P004',
    name: 'Kertas HVS Sinar Dunia (SiDU) F4 80gsm',
    brand: 'Sinar Dunia',
    size: 'F4',
    weight: '80 gsm',
    priceText: 'Rp 285.000',
    pricePerUnit: 285000,
    unitType: 'Karton (5 Rim)',
    stock: 3980,
    description: 'Kertas HVS premium F4 (Folio) bermerk Sinar Dunia dengan ketebalan prima 80 gsm. Mengindikasikan hasil cetak profesional tebal, mantap, warna warna lebih cerah berkat teknologi TRUTONE. Cocok untuk proposal bisnis dan dokumen penting.',
    imageUrl: '/assets/images/regenerated_image_1780228019007.jpg',
    featured: false,
    rating: 4.9,
    reviewsCount: 198
  },
  {
    id: 'P005',
    name: 'Kertas HVS e-Paper Premium Office A4 80gsm',
    brand: 'e-Paper',
    size: 'A4',
    weight: '80 gsm',
    priceText: 'Rp 275.000',
    pricePerUnit: 275000,
    unitType: 'Karton (5 Rim)',
    stock: 2120,
    description: 'Kertas ramah lingkungan (eco-friendly) dengan sertifikasi legalitas kelestarian hutan. Kertas e-Paper A4 80gsm memberikan warna putih alami yang teduh di mata namun kontras cetak tinggi. Serat ultra-halus menghemat penggunaan tinta/toner.',
    imageUrl: '/assets/images/regenerated_image_1780228021865.jpg',
    featured: true,
    rating: 4.8,
    reviewsCount: 154
  },
  {
    id: 'P006',
    name: 'Kertas HVS e-Paper Multipurpose F4 70gsm',
    brand: 'e-Paper',
    size: 'F4',
    weight: '70 gsm',
    priceText: 'Rp 255.000',
    pricePerUnit: 255000,
    unitType: 'Karton (5 Rim)',
    stock: 2115,
    description: 'e-Paper ukuran Folio F4 ketebalan 70 gsm. Pilihan ekonomis berkualitas tinggi yang diproduksi dengan komitmen emisi rendah karbon. Hasil cetak teks tajam, stabil, tahan lama, dan tidak mudah menguning.',
    imageUrl: '/assets/images/regenerated_image_1780228022538.webp',
    featured: false,
    rating: 4.7,
    reviewsCount: 125
  },
  {
    id: 'P007',
    name: 'Buku Tulis Sinar Dunia (SiDU) 38 Lembar',
    brand: 'Sinar Dunia',
    size: 'Buku Tulis',
    weight: '38 Lembar',
    priceText: 'Rp 48.000',
    pricePerUnit: 48000,
    unitType: 'Pak (10 Buku)',
    stock: 8450,
    description: 'Buku Tulis Sinar Dunia isi 38 lembar per buku. Hadir dalam 1 pak berisi 10 buku dengan motif gambar cover yang menarik, mengedukasi, dan penuh semangat. Lembaran bergaris presisi dengan kertas putih halus bermutu tinggi khas SiDU.',
    imageUrl: '/assets/images/regenerated_image_1780228023257.jpg',
    featured: true,
    rating: 5.0,
    reviewsCount: 612
  },
  {
    id: 'P008',
    name: 'Buku Tulis Sinar Dunia (SiDU) 58 Lembar',
    brand: 'Sinar Dunia',
    size: 'Buku Tulis',
    weight: '58 Lembar',
    priceText: 'Rp 65.000',
    pricePerUnit: 65000,
    unitType: 'Pak (10 Buku)',
    stock: 6320,
    description: 'Buku Tulis Sinar Dunia dengan ketebalan ekstra isi 58 lembar per buku. Ideal untuk mata pelajaran sekolah sekunder, jurnal harian, catatan perkuliahan, atau coretan kreatif. Jilid lem kokoh dan jahitan aman tidak mudah copot.',
    imageUrl: '/assets/images/regenerated_image_1780228025421.webp',
    featured: true,
    rating: 5.0,
    reviewsCount: 479
  }
];

export const MOCK_ORDERS: Order[] = [
  {
    id: 'DSC-88219-BTM',
    customer: {
      name: 'Budi Santoso (Sekolah harapan Mandiri)',
      phone: '0812-7012-3490',
      email: 'budi.santoso@harapanmandiri.sch.id',
      address: 'Jl. Ahmad Yani No. 12, Kel. Teluk Tering',
      distric: 'Batam Kota'
    },
    items: [
      { product: PRODUCTS[0], quantity: 10 }, // PaperOne A4 80gsm x 10
      { product: PRODUCTS[6], quantity: 5 }   // Buku SiDU 38 lbr x 5
    ],
    totalAmount: 3190000,
    orderDate: '2026-05-30T09:15:00Z',
    paymentStatus: 'Lunas',
    shippingStatus: 'Kurir Mengirim',
    trackingNumber: 'TRK-DATASCRIP-2601',
    shippingNote: 'Kurir (Pak Rahmat) sedang mengantarkan pesanan ke Gedung Tata Usaha Sekolah. ETA 13:45 WIB.'
  },
  {
    id: 'DSC-41005-BTM',
    customer: {
      name: 'CV. Maju Jaya Abadi (Nagoya)',
      phone: '0852-6411-9281',
      email: 'majujayabtm@gmail.com',
      address: 'Komp. Nagoya Hill Blok R No. 4',
      distric: 'Lubuk Baja (Nagoya)'
    },
    items: [
      { product: PRODUCTS[2], quantity: 4 }, // SiDU A4 70gsm x 4
      { product: PRODUCTS[1], quantity: 2 }  // PaperOne F4 70gsm x 2
    ],
    totalAmount: 1540000,
    orderDate: '2026-05-31T08:30:00Z',
    paymentStatus: 'Menunggu Verifikasi',
    shippingStatus: 'Diproses',
    trackingNumber: 'TRK-DATASCRIP-2602',
    shippingNote: 'Selesai disiapkan di gudang utama PT. Datascrip Indonesia Cabang Batam. Menunggu jemputan kurir logistik.'
  }
];
