export interface Product {
  id: string;
  name: string;
  brand: 'Sinar Dunia' | 'e-Paper' | 'PaperOne';
  size: 'A4' | 'F4' | 'Buku Tulis';
  weight: '70 gsm' | '80 gsm' | '38 Lembar' | '58 Lembar';
  priceText: string;
  pricePerUnit: number; // in IDR
  unitType: 'Karton (5 Rim)' | 'Pak (10 Buku)';
  stock: number;
  description: string;
  imageUrl: string;
  featured: boolean;
  rating?: number;
  reviewsCount?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface CustomerProfile {
  name: string;
  phone: string;
  email: string;
  address: string;
  distric: string; // Batam districts: e.g. Batam Kota, Sekupang, Nagoya, dll
}

export interface Order {
  id: string; // SKU or Dynamic Order UUID eg: REG-2026-XXXX
  customer: CustomerProfile;
  items: CartItem[];
  totalAmount: number;
  orderDate: string;
  paymentStatus: 'Belum Bayar' | 'Menunggu Verifikasi' | 'Lunas';
  shippingStatus: 'Diterima Admin' | 'Diproses' | 'Dalam Perjalanan' | 'Kurir Mengirim' | 'Selesai';
  trackingNumber: string;
  paymentProofUrl?: string;
  shippingNote?: string;
}

export interface TrackingStep {
  status: 'Diterima Admin' | 'Diproses' | 'Dalam Perjalanan' | 'Kurir Mengirim' | 'Selesai';
  label: string;
  time: string;
  description: string;
  isCompleted: boolean;
  isCurrent: boolean;
}

export interface CompanyInfo {
  name: string;
  address: string;
  email: string;
  bankAccount: {
    bankName: string;
    accountNumber: string;
    accountHolder: string;
  };
  whatsapp: string;
}

export const COMPANY_PROFILE: CompanyInfo = {
  name: 'PT. DATASCRIP INDONESIA',
  address: 'Komp. Ruko Batam Center, Lt. 2, Kota Batam, Kepulauan Riau',
  email: 'datascripindonesia@gmail.com',
  bankAccount: {
    bankName: 'Bank OCBC INDONESIA',
    accountNumber: '9408 1006 3823',
    accountHolder: 'SALMI AIDI ANASTY'
  },
  whatsapp: '+62 851-6599-0362'
};
