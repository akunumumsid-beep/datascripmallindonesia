import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, Key, ClipboardCheck, ArrowRight, Save, LogOut, FileText, ShoppingBag, Truck, ExternalLink } from 'lucide-react';
import { CustomerProfile, Order } from '../types';
import { BATAM_DISTRICTS } from '../data';

interface AccountManagementProps {
  currentUser: CustomerProfile | null;
  onLogin: (profile: CustomerProfile) => void;
  onLogout: () => void;
  onUpdateProfile: (profile: CustomerProfile) => void;
  orderHistory: Order[];
  onTrackOrder: (orderId: string) => void;
}

export default function AccountManagement({
  currentUser,
  onLogin,
  onLogout,
  onUpdateProfile,
  orderHistory,
  onTrackOrder
}: AccountManagementProps) {
  // Login fields
  const [nameInput, setNameInput] = useState('');
  const [phoneInput, setPhoneInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [addressInput, setAddressInput] = useState('');
  const [districtInput, setDistrictInput] = useState(BATAM_DISTRICTS[0]);
  const [isRegistering, setIsRegistering] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Profile Edit fields
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [editDistrict, setEditDistrict] = useState('');

  const initEditForm = () => {
    if (currentUser) {
      setEditName(currentUser.name);
      setEditPhone(currentUser.phone);
      setEditEmail(currentUser.email);
      setEditAddress(currentUser.address);
      setEditDistrict(currentUser.distric);
      setEditMode(true);
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim() || !editPhone.trim() || !editAddress.trim()) {
      alert('Mohon lengkapi nama, nomor telepon, dan alamat pengiriman.');
      return;
    }
    const updated: CustomerProfile = {
      name: editName,
      phone: editPhone,
      email: editEmail,
      address: editAddress,
      distric: editDistrict
    };
    onUpdateProfile(updated);
    setEditMode(false);
    setSuccessMsg('Profil berhasil diperbarui!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim() || !phoneInput.trim() || !addressInput.trim()) {
      alert('Mohon isi semua data formulir registrasi/masuk.');
      return;
    }
    const newProfile: CustomerProfile = {
      name: nameInput,
      phone: phoneInput,
      email: emailInput || 'pelanggan@example.com',
      address: addressInput,
      distric: districtInput
    };
    onLogin(newProfile);
    // Reset
    setNameInput('');
    setPhoneInput('');
    setEmailInput('');
    setAddressInput('');
    setSuccessMsg('Berhasil masuk ke akun Anda!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const fillDemoAccount = () => {
    setNameInput('Ahmad Subarjo');
    setPhoneInput('0813-7221-5099');
    setEmailInput('ahmad.subarjo@yahoo.com');
    setAddressInput('Ruko Mega Legend Blok C3 No. 10 (Samping Optik)');
    setDistrictInput('Batam Kota');
  };

  const handleCopy = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(num);
  };

  return (
    <div className="font-sans text-left max-w-6xl mx-auto">
      {successMsg && (
        <div className="mb-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl p-4 text-xs font-bold flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          {successMsg}
        </div>
      )}

      {!currentUser ? (
        /* Login / Register Form */
        <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden max-w-lg mx-auto">
          <div className="bg-blue-700 p-6 text-white text-center">
            <h3 className="text-lg font-black tracking-tight">Portal Manajemen Akun Pelanggan</h3>
            <p className="text-xs text-blue-100 mt-1">
              Masuk atau Daftar gratis untuk pelacakan otomatis & pemesanan instan
            </p>
          </div>

          <form onSubmit={handleAuthSubmit} className="p-6 space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">ID / Nama Lengkap Anda:</label>
              <div className="relative">
                <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder="Contoh: Ahmad Subarjo atau CV. Mandiri"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-slate-800"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Nomor WhatsApp Aktif:</label>
              <div className="relative">
                <Phone className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="tel"
                  required
                  placeholder="Contoh: 0812-3456-7890"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-slate-800"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Alamat Email Bisnis (Opsional):</label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  placeholder="Contoh: nama@perusahaan.com"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-slate-800"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="space-y-1 sm:col-span-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Kecamatan Pengiriman di Batam:</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <select
                    value={districtInput}
                    onChange={(e) => setDistrictInput(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-slate-800 h-9"
                  >
                    {BATAM_DISTRICTS.map((dst) => (
                      <option key={dst} value={dst}>{dst}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Alamat Jalan Lengkap Pengiriman:</label>
              <textarea
                required
                rows={2}
                placeholder="Tulis nama jalan, nomor ruko, gedung, lantai, kelurahan lengkap..."
                value={addressInput}
                onChange={(e) => setAddressInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-slate-800"
              />
            </div>

            <div className="pt-3 flex flex-col gap-2">
              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-3 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                Simpan & Masuk Akun
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={fillDemoAccount}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px] py-2 rounded-xl transition-all cursor-pointer"
              >
                ⚡ Isi Cepat Akun Simulasi / Demo Pelanggan
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* Logged In Dashboard layout */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left panel: Profile view/edit */}
          <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-6 h-fit">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
                <User className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h3 className="text-sm font-black text-slate-800">Profil Pelanggan</h3>
                <p className="text-[10px] text-slate-400 font-mono">ID: DSC-{currentUser.phone.substring(currentUser.phone.length - 4)}</p>
              </div>
            </div>

            {!editMode ? (
              <div className="space-y-4 text-xs">
                <div className="pb-3 border-b border-slate-50">
                  <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Nama / Perusahaan</span>
                  <span className="font-bold text-slate-800 text-sm mt-0.5 block">{currentUser.name}</span>
                </div>
                
                <div className="pb-3 border-b border-slate-50">
                  <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">No. WhatsApp Hubungan</span>
                  <span className="font-semibold text-slate-700 block mt-0.5">{currentUser.phone}</span>
                </div>

                <div className="pb-3 border-b border-slate-50">
                  <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Email Bisnis</span>
                  <span className="font-semibold text-slate-700 block mt-0.5">{currentUser.email}</span>
                </div>

                <div className="pb-3 border-b border-slate-50">
                  <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Kecamatan Default</span>
                  <span className="font-bold text-blue-700 block mt-0.5">{currentUser.distric}</span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Alamat Pengiriman Utama</span>
                  <span className="font-medium text-slate-600 block mt-0.5 leading-relaxed">{currentUser.address}</span>
                </div>

                <div className="pt-4 flex gap-2">
                  <button
                    onClick={initEditForm}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-2 rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" />
                    Ubah Sandi / Profil
                  </button>
                  <button
                    onClick={onLogout}
                    title="Keluar"
                    className="bg-red-50 hover:bg-red-100 text-red-600 p-2 rounded-xl transition-all border border-red-100 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              /* Profile edit form */
              <form onSubmit={handleSaveProfile} className="space-y-3.5">
                <div className="space-y-0.5">
                  <label className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Nama Lengkap</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs outline-none text-slate-850 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-0.5">
                  <label className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Nomor Telepon</label>
                  <input
                    type="tel"
                    required
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs outline-none text-slate-850 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-0.5">
                  <label className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Email Bisnis</label>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs outline-none text-slate-850 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-0.5">
                  <label className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Kecamatan Batam</label>
                  <select
                    value={editDistrict}
                    onChange={(e) => setEditDistrict(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs outline-none text-slate-850 focus:ring-1 focus:ring-blue-500 h-[34px]"
                  >
                    {BATAM_DISTRICTS.map((dst) => (
                      <option key={dst} value={dst}>{dst}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-0.5">
                  <label className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Alamat Jalan</label>
                  <textarea
                    rows={2}
                    value={editAddress}
                    onChange={(e) => setEditAddress(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs outline-none text-slate-850 focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-xl text-xs cursor-pointer"
                  >
                    Simpan Perubahan
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditMode(false)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 px-3 rounded-xl text-xs cursor-pointer"
                  >
                    Batal
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Right panel: Historical list of orders */}
          <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-6">
            <div className="flex justify-between items-center pb-4 border-b border-slate-50">
              <div className="text-left">
                <h3 className="text-sm font-black text-slate-800">Riwayat Pesanan Anda (Batam)</h3>
                <p className="text-xs text-slate-400">Total {orderHistory.length} pesanan tercatat di PT. Datascrip</p>
              </div>
              <div className="bg-blue-50 text-blue-700 px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5">
                <FileText className="w-4 h-4" />
                Daftar Dokumen
              </div>
            </div>

            {orderHistory.length === 0 ? (
              <div className="py-12 text-center max-w-sm mx-auto space-y-3">
                <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-slate-350 mx-auto border border-dashed border-slate-200">
                  <ShoppingBag className="w-5 h-5 animate-pulse" />
                </div>
                <h4 className="text-xs font-bold text-slate-700">Belum Ada Pesanan Aktif</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Silakan jelajahi katalog produk, pilih jenis ukuran kertas Anda (A4 / F4) dan buat pesanan online perdana.
                </p>
              </div>
            ) : (
              <div className="space-y-4.5 overflow-hidden">
                {orderHistory.map((order) => (
                  <div
                    key={order.id}
                    className="border border-slate-100 rounded-2xl p-4.5 bg-slate-50 hover:bg-slate-50/75 transition-all text-left space-y-3 relative"
                  >
                    {/* Invoice ID Header & action badges */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-white">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-extrabold text-slate-800 font-mono">{order.id}</span>
                          <button
                            onClick={() => handleCopy(order.id)}
                            className="text-slate-400 hover:text-slate-600 py-0.5 px-1 rounded-md transition-colors"
                            title="Salin No. Invoice"
                          >
                            <ClipboardCheck className={`w-3.5 h-3.5 ${copiedId === order.id ? 'text-emerald-500' : ''}`} />
                          </button>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Tanggal: {new Date(order.orderDate).toLocaleDateString('id-ID', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })} WIB
                        </span>
                      </div>

                      {/* Side badges */}
                      <div className="flex gap-2">
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          order.paymentStatus === 'Lunas' ? 'bg-emerald-100 text-emerald-800' :
                          order.paymentStatus === 'Menunggu Verifikasi' ? 'bg-amber-100 text-amber-800' :
                          'bg-rose-100 text-rose-800'
                        }`}>
                          Pembayaran: {order.paymentStatus}
                        </span>
                        <span className="text-[9px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                          Kiriman: {order.shippingStatus}
                        </span>
                      </div>
                    </div>

                    {/* Bought products detail list */}
                    <div className="space-y-1.5 pl-1.5 border-l-2 border-blue-200">
                      {order.items.map((it, idx) => (
                        <div key={idx} className="flex justify-between text-xs text-slate-600">
                          <span className="font-semibold truncate max-w-sm">
                            {it.product.name} (x{it.quantity} {it.product.unitType.split(' ')[0]})
                          </span>
                          <span className="font-mono">{formatIDR(it.product.pricePerUnit * it.quantity)}</span>
                        </div>
                      ))}
                    </div>

                    {/* Shipping Address Note */}
                    <div className="text-[11px] text-slate-500 bg-white/60 p-2.5 rounded-xl border border-white">
                      <strong>Alamat Kirim ({order.customer.distric}):</strong> {order.customer.address}
                    </div>

                    {/* Footer price & tracking redirect icon link */}
                    <div className="flex justify-between items-center pt-2 pb-0.5">
                      <div>
                        <span className="text-[10px] text-slate-400 block引领-none">Total Nilai Pembelian:</span>
                        <span className="text-sm font-black font-mono text-blue-900">{formatIDR(order.totalAmount)}</span>
                      </div>

                      <button
                        onClick={() => onTrackOrder(order.id)}
                        className="bg-blue-600 hover:bg-blue-700 text-white hover:text-white font-bold text-[10px] px-3.5 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-sm"
                      >
                        <Truck className="w-3.5 h-3.5 animate-pulse" />
                        Lacak Detail Live
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
