import React, { useState } from 'react';
import { Search, MapPin, Truck, CheckCircle2, User, Clock, ShieldAlert, ArrowRight, CornerDownRight } from 'lucide-react';
import { Order, TrackingStep } from '../types';
import { MOCK_ORDERS } from '../data';

interface ShipmentTrackerProps {
  orders: Order[];
  defaultSearchId?: string;
}

export default function ShipmentTracker({ orders, defaultSearchId = '' }: ShipmentTrackerProps) {
  const [searchId, setSearchId] = useState(defaultSearchId);
  const [trackedOrder, setTrackedOrder] = useState<Order | null>(
    defaultSearchId ? (orders.find((o) => o.id === defaultSearchId) || null) : null
  );
  const [hasSearched, setHasSearched] = useState(!!defaultSearchId);

  // Combine parent orders + mock default ones to let customer search seamlessly!
  const allOrdersList = [...orders, ...MOCK_ORDERS];

  // Helper search action
  const handleTrackSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) {
      alert('Masukkan nomor Invoice atau ID pelacakan PT. Datascrip terlebih dahulu.');
      return;
    }
    const match = allOrdersList.find(
      (o) => o.id.toLowerCase().trim() === searchId.toLowerCase().trim() || 
             o.trackingNumber.toLowerCase().trim() === searchId.toLowerCase().trim()
    );
    setTrackedOrder(match || null);
    setHasSearched(true);
  };

  const selectDemoTrack = (id: string) => {
    setSearchId(id);
    const match = allOrdersList.find((o) => o.id === id);
    setTrackedOrder(match || null);
    setHasSearched(true);
  };

  // Convert current status into beautiful steps
  const getTrackingSteps = (order: Order): TrackingStep[] => {
    const statuses: Order['shippingStatus'][] = [
      'Diterima Admin',
      'Diproses',
      'Dalam Perjalanan',
      'Kurir Mengirim',
      'Selesai'
    ];

    const labels = {
      'Diterima Admin': 'Aduan & Validasi Pembayaran',
      'Diproses': 'Pengemasan di Depo Batam',
      'Dalam Perjalanan': 'Armada Angkutan Logistik',
      'Kurir Mengirim': 'Pengiriman Kurir Lokal',
      'Selesai': 'Serah Terima Selesai'
    };

    const descriptions = {
      'Diterima Admin': 'Bukti transfer tercatat dan divalidasi oleh kasir PT. Datascrip Batam.',
      'Diproses': 'Kertas dipilah, dikemas rapi dengan pelindung palet kayu/plastik anti lembab.',
      'Dalam Perjalanan': 'Pesanan dimuat ke mobil Isuzu Box PT. Datascrip menuju hub transit.',
      'Kurir Mengirim': 'Barang dibawa langsung oleh kurir logistik (PIC: Pak Rahmat) ke lokasi tujuan.',
      'Selesai': 'Paketan kertas HVS/Buku telah diterima oleh PIC penerima dengan kondisi utuh.'
    };

    const currentIdx = statuses.indexOf(order.shippingStatus);
    
    // Static dummy timings relative to order dates
    const baseHour = new Date(order.orderDate);

    return statuses.map((st, idx) => {
      const stepHour = new Date(baseHour);
      stepHour.setHours(baseHour.getHours() + idx * 3); // increment by 3 hrs
      
      const timeText = idx <= currentIdx 
        ? stepHour.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB'
        : 'Estimasi';

      return {
        status: st,
        label: labels[st],
        time: timeText,
        description: descriptions[st],
        isCompleted: idx < currentIdx,
        isCurrent: idx === currentIdx
      };
    });
  };

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(num);
  };

  return (
    <div className="font-sans text-left max-w-5xl mx-auto space-y-6">
      
      {/* Tracker search block */}
      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
        <div className="max-w-2xl text-left space-y-1">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wide">
            Sistem Pelacakan Pengiriman Terintegrasi (Batam Hub)
          </h3>
          <p className="text-xs text-slate-500">
            Dapatkan detail pelacakan real-time armada pengantar kertas PT. Datascrip. Masukkan No. Invoice atau Nomor Tracking Anda.
          </p>
        </div>

        <form onSubmit={handleTrackSearch} className="flex gap-2 max-w-2xl">
          <div className="relative flex-1">
            <Search className="w-4.5 h-4.5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Masukkan ID Invoice (Contoh: DSC-88219-BTM)"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-250 rounded-xl pl-10 pr-4 py-2.5 text-xs focus:ring-1 focus:ring-blue-500 outline-none text-slate-800 font-mono tracking-wide"
            />
          </div>
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 text-white font-black text-xs px-6 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
          >
            Lacak Pesanan
          </button>
        </form>

        {/* Demo trigger quick-links */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
            Demo Cepat / Klik Lacak Klik:
          </span>
          <button
            onClick={() => selectDemoTrack('DSC-88219-BTM')}
            className="bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-[10px] px-3 py-1 rounded-lg transition-colors cursor-pointer"
          >
            📍 Lacak DSC-88219-BTM (Kurir Mengirim)
          </button>
          <button
            onClick={() => selectDemoTrack('DSC-41005-BTM')}
            className="bg-amber-50 hover:bg-amber-100 text-amber-700 font-bold text-[10px] px-3 py-1 rounded-lg transition-colors cursor-pointer"
          >
            📍 Lacak DSC-41005-BTM (Depo Diproses)
          </button>
        </div>
      </div>

      {hasSearched && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left panel: Timeline results */}
          {trackedOrder ? (
            <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-100 p-6 space-y-6 shadow-sm">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-4 border-b border-slate-100">
                <div className="text-left">
                  <span className="text-[10px] text-blue-700 font-extrabold uppercase font-mono">
                    Invoice: {trackedOrder.id}
                  </span>
                  <h4 className="text-sm font-black text-slate-800">
                    Status: <span className="text-blue-700">{trackedOrder.shippingStatus}</span>
                  </h4>
                </div>
                
                <div className="text-left sm:text-right">
                  <span className="text-[10px] text-slate-400 block font-mono">Nomor No. Tracking:</span>
                  <span className="text-xs font-bold text-slate-700 font-mono">{trackedOrder.trackingNumber}</span>
                </div>
              </div>

              {/* Courier active notes */}
              {trackedOrder.shippingNote && (
                <div className="bg-blue-50/50 rounded-2xl p-4 border border-blue-100 flex gap-3 text-xs leading-relaxed text-blue-900">
                  <div className="bg-blue-500 text-white rounded-xl p-2 shrink-0 h-fit">
                    <Truck className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <span className="font-bold block text-blue-950 mb-0.5">Catatan Logistik Lapangan:</span>
                    <p className="text-blue-800">{trackedOrder.shippingNote}</p>
                  </div>
                </div>
              )}

              {/* Timeline layout vertical steps */}
              <div className="space-y-4">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block pb-2 border-b border-slate-50">
                  Riwayat Milestone Logistik (Batam):
                </span>

                <div className="relative pl-6 space-y-6">
                  {/* Vertical stem connector line */}
                  <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-slate-100"></div>

                  {getTrackingSteps(trackedOrder).map((step, idx) => (
                    <div key={idx} className="relative flex gap-4 text-xs transition-opacity">
                      
                      {/* Circle indicator bullet */}
                      <span className={`absolute left-[-21px] top-1 w-6 h-6 rounded-full border-2 flex items-center justify-center z-10 font-bold transition-all ${
                        step.isCurrent ? 'bg-blue-600 text-white border-blue-600' :
                        step.isCompleted ? 'bg-blue-100 text-blue-700 border-blue-100' :
                        'bg-white text-slate-400 border-slate-200'
                      }`}>
                        {step.isCompleted ? <CheckCircle2 className="w-4 h-4 shrink-0 text-blue-600" /> : idx + 1}
                      </span>

                      {/* Content block */}
                      <div className="flex-1 text-left">
                        <div className="flex justify-between items-baseline mb-0.5">
                          <h5 className={`font-bold ${step.isCurrent ? 'text-blue-900 text-sm' : 'text-slate-750'}`}>
                            {step.status}
                          </h5>
                          <span className="text-[10px] text-slate-400 font-mono shrink-0 pl-2">
                            {step.time}
                          </span>
                        </div>
                        <p className="text-[10px] font-semibold text-slate-550 leading-none mb-1 text-slate-500">
                          {step.label}
                        </p>
                        <p className="text-[11px] text-slate-500 leading-relaxed">
                          {step.description}
                        </p>
                      </div>

                    </div>
                  ))}
                </div>
              </div>

              {/* Static specs brief summary */}
              <div className="pt-4.5 border-t border-slate-100 flex justify-between text-xs text-slate-500">
                <div>
                  <span className="text-[10px] text-slate-400">Tujuan Kecamatan:</span>
                  <p className="font-bold text-slate-700 block">{trackedOrder.customer.distric}</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400">Total Belanja:</span>
                  <p className="font-bold text-blue-955 font-mono tracking-tight">{formatIDR(trackedOrder.totalAmount)}</p>
                </div>
              </div>

            </div>
          ) : (
            /* Render not-found state */
            <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-100 p-8 text-center shadow-lg space-y-4">
              <div className="w-12 h-12 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto border border-rose-100">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div className="max-w-md mx-auto space-y-1">
                <h4 className="text-sm font-black text-slate-800">Kode Invoice Tidak Ditemukan</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Kami tidak mendeteksi pesanan aktif dengan kode <strong>"{searchId}"</strong> di database PT. Datascrip Batam.
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl text-left text-xs text-slate-600 border border-slate-100 max-w-md mx-auto space-y-2">
                <span className="font-bold flex items-center gap-1.5 text-slate-700">
                  <CornerDownRight className="w-4 h-4 text-blue-500" /> Tips Pelacakan:
                </span>
                <ul className="list-disc pl-5 space-y-1 text-slate-500">
                  <li>Pastikan Anda menyalin Invoice ID persis tanpa ada spasi ekstra.</li>
                  <li>Pelacakan manual dapat dibuat dengan mendaftarkan order baru di halaman katalog belanja terlebih dahulu.</li>
                  <li>Hubungi representasi kami melalui widget WhatsApp di kanan bawah untuk cek manual.</li>
                </ul>
              </div>
            </div>
          )}

          {/* Right panel: Static mock visual locator tracking radar of Batam Island routes */}
          <div className="lg:col-span-5 bg-slate-900 text-white rounded-3xl p-6 space-y-5 border border-slate-800 shadow-xl overflow-hidden relative">
            <div className="absolute top-0 right-0 w-44 h-44 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none"></div>
            
            <div className="text-left">
              <span className="text-[10px] bg-cyan-950 text-cyan-400 font-bold font-mono px-2 py-0.5 rounded-full uppercase tracking-wider">
                Satelit Telemetri
              </span>
              <h4 className="text-sm font-black text-slate-100 mt-1 uppercase tracking-tight">
                Simulasi Radar Rute Batam
              </h4>
              <p className="text-[10px] text-slate-400 leading-tight">
                Posisi logistik terpantau real-time dari Gudang Utama Datascrip Batam Center.
              </p>
            </div>

            {/* Simulated Radar UI Area */}
            <div className="relative aspect-video rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col justify-center items-center">
              
              {/* Concentric circle grids to animate radar */}
              <div className="absolute w-24 h-24 border border-cyan-500/10 rounded-full animate-ping pointer-events-none"></div>
              <div className="absolute w-44 h-44 border border-blue-500/10 rounded-full pointer-events-none"></div>
              <div className="absolute w-[300px] h-[300px] border border-slate-500/5 rounded-full pointer-events-none"></div>

              {/* Transit lines */}
              <div className="absolute inset-0 flex items-center justify-center opacity-10">
                <div className="w-full h-0.5 bg-slate-400 border-dashed"></div>
                <div className="h-full w-0.5 bg-slate-400 border-dashed absolute"></div>
              </div>

              {/* Simulated Map points overlay representing Batam hotspots */}
              <div className="absolute top-[25%] left-[20%] text-center">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-600 block mx-auto relative cursor-pointer"></span>
                <span className="text-[8px] font-mono text-slate-400 uppercase tracking-widest mt-0.5 block scale-90">Sekupang Hub</span>
              </div>

              <div className="absolute top-[18%] right-[25%] text-center">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-600 block mx-auto relative cursor-pointer"></span>
                <span className="text-[8px] font-mono text-slate-400 uppercase tracking-widest mt-0.5 block scale-90">Nongsa Hub</span>
              </div>

              <div className="absolute bottom-[22%] left-[45%] text-center">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-600 block mx-auto relative cursor-pointer"></span>
                <span className="text-[8px] font-mono text-slate-400 uppercase tracking-widest mt-0.5 block scale-90">Batu Aji Hub</span>
              </div>

              {/* Primary Anchor: PT. Datascrip Batam Warehouse */}
              <div className="absolute top-[48%] left-[52%] text-center z-10">
                <span className="w-3.5 h-3.5 rounded-full bg-blue-500 block mx-auto relative cursor-pointer shadow-md shadow-blue-500/50">
                  <span className="absolute inset-0 bg-blue-400 rounded-full animate-ping"></span>
                </span>
                <span className="text-[8px] font-extrabold text-blue-300 uppercase mt-0.5 block font-sans tracking-wide">Gudang Utama DI</span>
              </div>

              {/* Target dynamic locator courier pointer if tracked order exists */}
              {trackedOrder && trackedOrder.shippingStatus !== 'Diterima Admin' && (
                <div className="absolute top-[60%] right-[32%] text-center z-20">
                  <span className="w-3.5 h-3.5 rounded-full bg-emerald-500 block mx-auto relative cursor-pointer shadow-md shadow-emerald-500/50">
                    <span className="absolute inset-0 bg-emerald-400 rounded-full animate-ping"></span>
                  </span>
                  <span className="text-[8px] font-extrabold text-emerald-400 uppercase mt-0.5 block font-mono">
                    Mobil Box: {trackedOrder.customer.distric.split(' ')[0]}
                  </span>
                </div>
              )}

              {/* Status info bar */}
              <div className="absolute bottom-2.5 left-2.5 right-2.5 bg-slate-900/90 backdrop-blur-xs p-2 rounded-xl text-[9px] font-mono border border-slate-800 text-left flex justify-between">
                <span className="text-cyan-400">GPS: TERHUBUNG</span>
                <span className="text-slate-400 uppercase">
                  Tujuan: {trackedOrder ? trackedOrder.customer.distric : 'Menunggu Input'}
                </span>
              </div>

            </div>

            {/* Static Batam delivery specifications */}
            <div className="space-y-2.5 text-xs text-left">
              <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider">
                Informasi Pengiriman Batam Kepri:
              </span>
              <p className="text-slate-350 leading-relaxed text-[11px]">
                Seluruh barang dikirim dari <strong>Komp. Ruko Batam Center</strong> menggunakan truk boks mandiri PT. Datascrip Indonesia demi menjamin kertas sampai tanpa tekukan/robek akibat panas/hujan laut.
              </p>
              <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 pt-1">
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-200 block text-xs">A4 dan F4</strong>
                  Stok HVS 70g & 80g aman.
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-200 block text-xs">Jatuh Tempo</strong>
                  COD khusus instansi mitra.
                </div>
              </div>
            </div>

          </div>

        </div>
      )}
    </div>
  );
}
