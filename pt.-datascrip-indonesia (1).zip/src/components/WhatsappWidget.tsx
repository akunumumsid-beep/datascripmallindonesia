import React, { useState, useEffect } from 'react';
import { MessageSquare, Calendar, Clock, ArrowUpRight, Send, Check } from 'lucide-react';
import { COMPANY_PROFILE } from '../types';

export default function WhatsappWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [showBubble, setShowBubble] = useState(false);

  useEffect(() => {
    // Show a small intro bubble after 3 seconds to catch attention
    const timer = setTimeout(() => {
      setShowBubble(true);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNumber = COMPANY_PROFILE.whatsapp.replace(/[^0-9]/g, '');
    const defaultText = message.trim() || 'Halo Admin Sinar Dunia & PaperOne, saya ingin bertanya tentang pasokan kertas HVS untuk kantor / grosir.';
    const encodedText = encodeURIComponent(defaultText);
    const whatsappUrl = `https://wa.me/${cleanNumber}?text=${encodedText}`;
    window.open(whatsappUrl, '_blank');
    setIsOpen(false);
  };

  const selectPreset = (text: string) => {
    setMessage(text);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans">
      {/* Dynamic welcome bubble */}
      {showBubble && !isOpen && (
        <div id="wa-welcome-bubble" className="absolute bottom-16 right-0 w-72 bg-white rounded-2xl shadow-xl border border-emerald-100 p-4 animate-bounce duration-1000">
          <div className="flex items-start gap-2.5">
            <div className="bg-emerald-500 text-white rounded-full p-1.5 mt-0.5">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold text-emerald-800">Admin PT. Datascrip</span>
                <button 
                  onClick={() => setShowBubble(false)} 
                  className="text-gray-400 hover:text-gray-600 text-[10px] uppercase font-bold"
                >
                  Tutup
                </button>
              </div>
              <p className="text-xs text-gray-600 mt-1">
                Ada yang bisa kami bantu? Butuh penawaran harga HVS grosir atau kustom buku tulis?
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Floating Button */}
      <button
        id="wa-float-btn"
        onClick={() => {
          setIsOpen(!isOpen);
          setShowBubble(false);
        }}
        className="bg-emerald-500 hover:bg-emerald-600 text-white p-4 rounded-full shadow-lg hover:shadow-2xl transition-all duration-300 flex items-center justify-center group relative cursor-pointer"
        aria-label="Contact WhatsApp Admin"
      >
        <MessageSquare className="w-6 h-6 group-hover:scale-110 transition-transform" />
        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full">
          1
        </span>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div id="wa-chat-window" className="absolute bottom-16 right-0 w-80 sm:w-96 bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden transform origin-bottom-right transition-all duration-300">
          {/* Header */}
          <div className="bg-emerald-600 p-4 text-white">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center font-bold text-lg text-white border-2 border-emerald-400">
                  DS
                </div>
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-emerald-600 rounded-full"></span>
              </div>
              <div>
                <h4 className="font-semibold text-sm">PT. DATASCRIP INDONESIA</h4>
                <p className="text-xs text-emerald-100">Batam Paper & Book Distributor</p>
                <p className="text-[10px] text-emerald-200 flex items-center gap-1 mt-0.5">
                  <span className="inline-block w-1.5 h-1.5 bg-emerald-200 rounded-full animate-ping"></span>
                  Online • Siap Melayani
                </p>
              </div>
            </div>
          </div>

          {/* Body */}
          <div className="p-4 bg-gray-50 max-h-80 overflow-y-auto">
            <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 mb-3 text-xs leading-relaxed text-gray-700">
              <p className="font-semibold text-emerald-800 mb-1">Halo Pelanggan Setia!</p>
              <p className="text-gray-600">
                Layanan pelanggan PT. Datascrip Indonesia Cabang Batam aktif melayani pemesanan langsung, 
                negosiasi tender/kontrak instansi, dan custom cetak buku tulis.
              </p>
              <div className="mt-2.5 pt-2 border-t border-gray-100 flex items-center gap-4 text-[10px] text-gray-400">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-emerald-600" /> Sen - Sab
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-emerald-600" /> 08:00 - 17:00
                </span>
              </div>
            </div>

            {/* Quick Templates */}
            <div className="mb-4">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-2">
                Pilih Pertanyaan Cepat:
              </span>
              <div className="space-y-1.5">
                {[
                  'Berapa harga grosir HVS PaperOne A4 80gsm per 100 Karton?',
                  'Apakah bisa kirim gratis ongkir ke wilayah Nagoya Batam?',
                  'Saya sedang mencari Buku Tulis SiDU isi 58 lembar stok banyak',
                  'Tanya status pesanan saya yang belum sampai'
                ].map((txt, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => selectPreset(txt)}
                    className="w-full text-left bg-white hover:bg-emerald-50 hover:border-emerald-200 p-2 rounded-xl text-xs text-gray-600 border border-gray-200 transition-all font-medium flex justify-between items-center group cursor-pointer"
                  >
                    <span className="truncate pr-2">{txt}</span>
                    <ArrowUpRight className="w-3 h-3 text-gray-400 group-hover:text-emerald-500 shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Footer Input */}
          <form onSubmit={handleSend} className="p-3 border-t border-gray-100 bg-white flex gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tulis pesan Anda..."
              className="flex-1 bg-gray-50 border border-gray-200 rounded-full px-4 py-2 text-xs focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-gray-800"
            />
            <button
              type="submit"
              className="bg-emerald-500 hover:bg-emerald-600 text-white p-2 rounded-full transition-all flex items-center justify-center shrink-0 cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
