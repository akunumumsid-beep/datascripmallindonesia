import { useState } from 'react';
import { Search, Filter, ShoppingBag, Eye, CheckCircle2, ChevronRight, X, AlertCircle } from 'lucide-react';
import { Product } from '../types';
import { PRODUCTS } from '../data';

interface ProductCatalogProps {
  onAddToCart: (product: Product, quantity: number) => void;
}

export default function ProductCatalog({ onAddToCart }: ProductCatalogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('Semua');
  const [selectedSize, setSelectedSize] = useState<string>('Semua');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [quantities, setQuantities] = useState<{ [key: string]: number }>({});
  const [addedAlert, setAddedAlert] = useState<{ [key: string]: boolean }>({});

  const filteredProducts = PRODUCTS.filter((p) => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesBrand = selectedBrand === 'Semua' || p.brand === selectedBrand;
    const matchesSize = selectedSize === 'Semua' || p.size === selectedSize;
    return matchesSearch && matchesBrand && matchesSize;
  });

  const handleQtyChange = (productId: string, val: number) => {
    const currentVal = quantities[productId] || 1;
    const newVal = Math.max(1, currentVal + val);
    setQuantities({ ...quantities, [productId]: newVal });
  };

  const handleAddToCartClick = (p: Product) => {
    const qty = quantities[p.id] || 1;
    onAddToCart(p, qty);
    
    // flash alert
    setAddedAlert({ ...addedAlert, [p.id]: true });
    setTimeout(() => {
      setAddedAlert((prev) => ({ ...prev, [p.id]: false }));
    }, 2000);
  };

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(num);
  };

  const getBrandBadgeStyle = (brand: string) => {
    switch (brand) {
      case 'PaperOne':
        return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'e-Paper':
        return 'bg-amber-50 text-amber-800 border-amber-100';
      case 'Sinar Dunia':
        return 'bg-purple-50 text-purple-700 border-purple-100';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-100';
    }
  };

  const getBannerBadge = (product: Product) => {
    if (product.size === 'Buku Tulis') {
      return 'Buku Tulis Sekolah';
    }
    return `HVS ${product.size} (${product.weight})`;
  };

  return (
    <div className="font-sans text-left">
      {/* Catalog Search & Controls */}
      <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm mb-6">
        <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
          
          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="w-4.5 h-4.5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari kertas, buku, gramatur..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2 text-xs focus:ring-1 focus:ring-blue-500 focus:bg-white outline-none text-slate-800"
            />
          </div>

          {/* Quick Filters */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {/* Brand filter */}
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 shrink-0">
                <Filter className="w-3.5 h-3.5 text-blue-600" />
                Merek:
              </span>
              <div className="flex gap-1">
                {['Semua', 'Sinar Dunia', 'e-Paper', 'PaperOne'].map((br) => (
                  <button
                    key={br}
                    onClick={() => setSelectedBrand(br)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                      selectedBrand === br
                        ? 'bg-blue-700 text-white shadow-sm'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-600'
                    }`}
                  >
                    {br}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Filter */}
            <div className="flex items-center gap-2 ml-auto md:ml-0">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block shrink-0">
                Ukuran:
              </span>
              <div className="flex gap-1">
                {['Semua', 'A4', 'F4', 'Buku Tulis'].map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                      selectedSize === sz
                        ? 'bg-blue-700 text-white shadow-sm'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-600'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Catalog Grid */}
      {filteredProducts.length === 0 ? (
        <div className="bg-slate-50 border border-dashed border-slate-200 rounded-3xl p-12 text-center max-w-xl mx-auto">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700">Katalog Tidak Ditemukan</h3>
          <p className="text-xs text-slate-500 mt-1">
            Maaf, tidak ada produk kertas, merek, atau ukuran yang sesuai dengan filter Anda. Silakan setel ulang filter pencarian Anda.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedBrand('Semua');
              setSelectedSize('Semua');
            }}
            className="mt-4 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all cursor-pointer"
          >
            Reset Semua Filter
          </button>
        </div>
      ) : (
        <div id="product-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((p) => {
            const qty = quantities[p.id] || 1;
            const hasAlert = addedAlert[p.id];
            
            return (
              <div
                id={`product-card-${p.id}`}
                key={p.id}
                className="bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-sm hover:shadow-lg hover:border-blue-150 transition-all flex flex-col group relative"
              >
                {/* Image & Badge Container */}
                <div className="relative h-48 bg-slate-50 overflow-hidden">
                  <img
                    src={p.imageUrl}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Brand Badge */}
                  <span className={`absolute top-3 left-3 border text-[10px] font-black px-2.5 py-1 rounded-full shadow-sm uppercase tracking-wide z-10 ${getBrandBadgeStyle(p.brand)}`}>
                    {p.brand}
                  </span>

                  {/* Size Specs Sticker */}
                  <span className="absolute bottom-3 right-3 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-bold px-2.5 py-1 rounded-lg">
                    {getBannerBadge(p)}
                  </span>
                </div>

                {/* Info details */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <span className="text-[10px] text-blue-700 font-extrabold uppercase tracking-wider font-mono">
                      SKU: DATASCRIP-{p.id}
                    </span>
                    
                    {/* Rating display */}
                    <div className="flex items-center gap-1 mt-0.5">
                      <div className="flex items-center text-amber-500">
                        <span className="text-sm">★</span>
                        <span className="text-[11px] font-bold text-slate-700 ml-0.5">{p.rating || 5.0}</span>
                      </div>
                      <span className="text-[10px] text-slate-400">({p.reviewsCount || 100}+ ulasan)</span>
                      <span className="text-[9px] font-extrabold text-emerald-800 bg-emerald-50 border border-emerald-100 px-1.5 py-0.5 rounded ml-auto">
                        Terlaris
                      </span>
                    </div>

                    <button
                      onClick={() => setSelectedProduct(p)}
                      className="text-left block cursor-pointer"
                    >
                      <h3 className="text-xs sm:text-sm font-bold text-slate-800 line-clamp-2 hover:text-blue-700 transition-colors">
                        {p.name}
                      </h3>
                    </button>
                    <p className="text-[11px] text-slate-500 line-clamp-2 mt-1 leading-relaxed">
                      {p.description}
                    </p>
                  </div>

                  {/* Pricing and Buying Interactions */}
                  <div className="mt-4 pt-4 border-t border-slate-50 space-y-3">
                    <div className="flex justify-between items-baseline">
                      <div>
                        <span className="text-slate-400 text-[10px] block leading-none">Harga Grosir:</span>
                        <span className="text-base font-black text-blue-950 font-mono tracking-tight">
                          {formatIDR(p.pricePerUnit)}
                        </span>
                      </div>
                      <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md uppercase font-mono">
                        {p.unitType}
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-[11px] text-slate-500">
                      <span>Stok Tersedia:</span>
                      <span className="font-extrabold text-emerald-600 flex items-center gap-1">
                        <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        {p.stock.toLocaleString('id-ID')} {p.unitType.split(' ')[0]} (Melimpah)
                      </span>
                    </div>

                    {/* Quantity selectors */}
                    <div className="flex items-center justify-between gap-2 pt-1">
                      <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
                        <button
                          type="button"
                          onClick={() => handleQtyChange(p.id, -1)}
                          className="px-2.5 py-1 hover:bg-slate-200 font-bold text-slate-500 transition-colors cursor-pointer"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs font-bold font-mono text-slate-700 min-w-6 text-center">
                          {qty}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleQtyChange(p.id, 1)}
                          className="px-2.5 py-1 hover:bg-slate-200 font-bold text-slate-500 transition-colors cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      <button
                        onClick={() => setSelectedProduct(p)}
                        title="Detail Produk"
                        className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 p-1.5 rounded-xl transition-all cursor-pointer"
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleAddToCartClick(p)}
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer hover:scale-[1.01]"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        Beli
                      </button>
                    </div>

                    {/* Added Toast Alert */}
                    {hasAlert && (
                      <div className="absolute inset-x-4 bottom-4 bg-emerald-500 text-white rounded-xl py-2 px-3 text-center text-[11px] font-bold shadow-lg flex items-center justify-center gap-1.5 animate-bounce z-20">
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        Ditambahkan ke Keranjang!
                      </div>
                    )}

                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Details Dialog Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 font-sans">
          <div
            id="detail-modal"
            className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-100 shadow-2xl animate-in fade-in zoom-in-95 duration-200"
          >
            {/* Modal Header */}
            <div className="relative h-64 bg-slate-50">
              <img
                src={selectedProduct.imageUrl}
                alt={selectedProduct.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent"></div>
              <button
                onClick={() => setSelectedProduct(null)}
                className="absolute top-4 right-4 bg-white/20 hover:bg-white/40 text-white p-2 rounded-full cursor-pointer transition-all border border-white/20"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6 text-white text-left z-10">
                <span className={`inline-block border text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wide mb-2 ${getBrandBadgeStyle(selectedProduct.brand)}`}>
                  {selectedProduct.brand}
                </span>
                <h3 className="text-lg sm:text-xl font-extrabold leading-tight shadow-text">
                  {selectedProduct.name}
                </h3>
                {/* Rating & Stock inside modal */}
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs">
                  <div className="flex items-center text-amber-400">
                    <span className="text-sm">★</span>
                    <span className="font-bold ml-1">{selectedProduct.rating || 5.0}</span>
                  </div>
                  <span className="text-slate-200 font-medium font-mono">({selectedProduct.reviewsCount || 100}+ Ulasan Pelanggan)</span>
                  <div className="flex items-center gap-1.5 text-emerald-300 font-bold">
                    <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    Pasokan Ready: {selectedProduct.stock.toLocaleString('id-ID')} {selectedProduct.unitType.split(' ')[0]} (Sangat Melimpah)
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 text-left">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 block mb-1">
                  Deskripsi & Spesifikasi Produk:
                </span>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {selectedProduct.description}
                </p>
              </div>

              {/* Specification Specs Table */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                <h4 className="text-xs font-bold text-slate-800 mb-3">Tabel Identitas Produk PT. Datascrip:</h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="bg-white p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Merek</span>
                    <span className="font-bold text-blue-900">{selectedProduct.brand}</span>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Ukuran / Jenis</span>
                    <span className="font-bold text-blue-900">{selectedProduct.size}</span>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Ketebalan / Gramatur</span>
                    <span className="font-bold text-blue-900">{selectedProduct.weight}</span>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-400 block">Minimum Order</span>
                    <span className="font-bold text-blue-900">1 {selectedProduct.unitType}</span>
                  </div>
                </div>
              </div>

              {/* Value Add / Key selling points based on product sizing */}
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 block mb-2">
                  Mengapa Membeli di PT. Datascrip Indonesia Cabang Batam?
                </span>
                <ul className="text-xs text-slate-600 space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500 shrink-0 mt-0.5" />
                    <span><strong>Jaminan Harga Gudang:</strong> Nilai kontrak khusus dapat ditawarkan untuk pembelian sekala besar (di atas 100 karton).</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500 shrink-0 mt-0.5" />
                    <span><strong>Keaslian Terjamin:</strong> Seluruh produk disuplai langsung dari pabrikan utama dengan segel barcode utuh.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500 shrink-0 mt-0.5" />
                    <span><strong>Armada Kurir Dedicated:</strong> Dikirim langsung menggunakan armada mobil PT. Datascrip, menjamin kertas tiba tanpa robek or lembab.</span>
                  </li>
                </ul>
              </div>

              {/* Action purchase */}
              <div className="border-t border-slate-100 pt-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-center sm:text-left">
                  <span className="text-[10px] text-slate-400 block">Harga Satuan Grosir:</span>
                  <span className="text-xl font-black text-blue-950 font-mono tracking-tight">
                    {formatIDR(selectedProduct.pricePerUnit)}
                  </span>
                  <span className="text-xs text-slate-505 font-bold ml-1.5">/ {selectedProduct.unitType}</span>
                </div>

                <div className="flex gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => {
                      handleAddToCartClick(selectedProduct);
                      setSelectedProduct(null);
                    }}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs px-6 py-3.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    Masukkan ke Keranjang Belanja
                  </button>
                  <button
                    onClick={() => setSelectedProduct(null)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-4 py-3.5 rounded-xl transition-all cursor-pointer"
                  >
                    Kembali
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
}
