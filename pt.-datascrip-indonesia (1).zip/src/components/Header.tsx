import { BookOpen, FileText, ShoppingCart, User, Truck, PhoneCall, HelpCircle } from 'lucide-react';
import { COMPANY_PROFILE, CustomerProfile } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  cartTotal: number;
  currentUser: CustomerProfile | null;
  onOpenCart: () => void;
  onLogout: () => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  cartCount,
  cartTotal,
  currentUser,
  onOpenCart,
  onLogout
}: HeaderProps) {
  const formatIDR = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(num);
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Brand/Logo Area */}
          <div className="flex items-center gap-3 text-left">
            <div className="flex items-center">
              <svg viewBox="0 0 100 100" className="w-11 h-11 drop-shadow-sm" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="6" y="6" width="88" height="88" stroke="#1d4ed8" strokeWidth="6" rx="4" fill="none" />
                <rect x="12" y="50" width="16" height="38" fill="#1d4ed8" />
                <rect x="34" y="12" width="16" height="76" fill="#1d4ed8" />
                <polygon points="56,12 88,12 88,44" fill="#1d4ed8" />
                <polygon points="56,88 88,88 88,56" fill="#1d4ed8" />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] bg-blue-50 text-blue-700 font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider">
                  Authorized Paper Distributor
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              </div>
              <h1 className="text-base font-black text-blue-950 leading-tight tracking-tight uppercase">
                PT. DATASCRIP INDONESIA
              </h1>
              <p className="text-[9px] text-slate-500 font-mono tracking-widest leading-none uppercase font-semibold mt-0.5">
                KOTA BATAM • KEPULAUAN RIAU
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200">
            <button
              id="nav-catalog"
              onClick={() => setActiveTab('catalog')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                activeTab === 'catalog'
                  ? 'bg-white text-blue-700 shadow-xs border border-slate-100'
                  : 'text-slate-600 hover:text-blue-700 hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              Katalog & Order
            </button>
            <button
              id="nav-tracking"
              onClick={() => setActiveTab('tracking')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                activeTab === 'tracking'
                  ? 'bg-white text-blue-700 shadow-xs border border-slate-100'
                  : 'text-slate-600 hover:text-blue-700 hover:bg-slate-100'
              }`}
            >
              <Truck className="w-4 h-4" />
              Pelacakan Real-time
            </button>
            <button
              id="nav-account"
              onClick={() => setActiveTab('account')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                activeTab === 'account'
                  ? 'bg-white text-blue-700 shadow-xs border border-slate-100'
                  : 'text-slate-600 hover:text-blue-700 hover:bg-slate-100'
              }`}
            >
              <User className="w-4 h-4" />
              {currentUser ? `Akun: ${currentUser.name.split(' ')[0]}` : 'Manajemen Akun'}
            </button>
            <button
              id="nav-profile"
              onClick={() => setActiveTab('profile')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                activeTab === 'profile'
                  ? 'bg-white text-blue-700 shadow-xs border border-slate-100'
                  : 'text-slate-600 hover:text-blue-700 hover:bg-slate-100'
              }`}
            >
              <HelpCircle className="w-4 h-4" />
              Info Distribusi
            </button>
          </nav>

          {/* Cart & User State Interactions */}
          <div className="flex items-center gap-3">
            {/* Shopping Cart Trigger */}
            <button
              id="cart-btn"
              onClick={onOpenCart}
              className="group relative flex items-center gap-2.5 bg-blue-50 hover:bg-blue-100 border border-blue-100 text-blue-800 px-4 py-2 rounded-lg transition-all shadow-xs cursor-pointer"
            >
              <div className="relative">
                <ShoppingCart className="w-4.5 h-4.5 group-hover:scale-105 transition-transform text-blue-700" />
                {cartCount > 0 && (
                  <span className="absolute -top-2.5 -right-2 bg-red-500 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white animate-pulse">
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="text-left hidden sm:block">
                <p className="text-[9px] text-blue-600 font-extrabold tracking-wide uppercase leading-none">Keranjang</p>
                <p className="text-xs font-bold font-mono tracking-tight text-blue-950 leading-none mt-0.5">
                  {cartTotal > 0 ? formatIDR(cartTotal) : 'Rp 0'}
                </p>
              </div>
            </button>

            {/* Micro Account Status for Desktop */}
            {currentUser && (
              <div className="hidden md:flex items-center gap-2 border-l border-slate-200 pl-3">
                <div className="text-right">
                  <p className="text-[10px] font-extrabold text-blue-700">Pelanggan Terdaftar</p>
                  <p className="text-xs font-medium text-slate-705 truncate max-w-[120px]">{currentUser.name}</p>
                </div>
                <button
                  id="header-logout-btn"
                  onClick={onLogout}
                  className="text-[10px] text-red-500 hover:text-red-700 font-bold hover:underline cursor-pointer"
                >
                  Keluar
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Sticky Tab Rail */}
      <div className="lg:hidden bg-slate-50 border-t border-slate-200 px-2 py-2 flex justify-around">
        <button
          onClick={() => setActiveTab('catalog')}
          className={`flex flex-col items-center gap-0.5 text-[9px] font-extrabold p-1 transition-all ${
            activeTab === 'catalog' ? 'text-blue-700' : 'text-slate-500 hover:text-slate-850'
          }`}
        >
          <BookOpen className="w-5 h-5" />
          Catalog
        </button>
        <button
          onClick={() => setActiveTab('tracking')}
          className={`flex flex-col items-center gap-0.5 text-[9px] font-extrabold p-1 transition-all ${
            activeTab === 'tracking' ? 'text-blue-700' : 'text-slate-500 hover:text-slate-850'
          }`}
        >
          <Truck className="w-5 h-5" />
          Lacak
        </button>
        <button
          onClick={() => setActiveTab('account')}
          className={`flex flex-col items-center gap-0.5 text-[9px] font-extrabold p-1 transition-all ${
            activeTab === 'account' ? 'text-blue-700' : 'text-slate-500 hover:text-slate-855'
          }`}
        >
          <User className="w-5 h-5" />
          Akun
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex flex-col items-center gap-0.5 text-[9px] font-extrabold p-1 transition-all ${
            activeTab === 'profile' ? 'text-blue-700' : 'text-slate-500 hover:text-slate-850'
          }`}
        >
          <HelpCircle className="w-5 h-5" />
          Info
        </button>
      </div>
    </header>
  );
}
