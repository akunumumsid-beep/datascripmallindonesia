import React, { useState, useEffect } from 'react';
import { X, Trash2, ShoppingBag, Landmark, ArrowRight, CheckCircle2, User, Phone, MapPin, Mail, ClipboardCopy, Send } from 'lucide-react';
import { CartItem, CustomerProfile, Order, COMPANY_PROFILE } from '../types';
import { BATAM_DISTRICTS } from '../data';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQty: (productId: string, qty: number) => void;
  onRemoveItem: (productId: string) => void;
  currentUser: CustomerProfile | null;
  onCompleteCheckout: (newOrder: Order) => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQty,
  onRemoveItem,
  currentUser,
  onCompleteCheckout
}: CartDrawerProps) {
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [copiedAcct, setCopiedAcct] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  // Form Fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [district, setDistrict] = useState(BATAM_DISTRICTS[0]);
  const [paymentProofAttached, setPaymentProofAttached] = useState(false);
  const [invoiceId, setInvoiceId] = useState('');

  // Prefill when currentUser changes or form opens
  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name);
      setPhone(currentUser.phone);
      setEmail(currentUser.email);
      setAddress(currentUser.address);
      setDistrict(currentUser.distric);
    }
  }, [currentUser, isOpen]);

  if (!isOpen) return null;

  const totalAmount = cartItems.reduce((acc, it) => acc + (it.product.pricePerUnit * it.quantity), 0);

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(num);
  };

  const handleCopyNum = () => {
    navigator.clipboard.writeText(COMPANY_PROFILE.bankAccount.accountNumber.replace(/\s/g, ''));
    setCopiedAcct(true);
    setTimeout(() => setCopiedAcct(false), 2000);
  };

  const handleCheckoutProcess = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0) return;
    if (!name.trim() || !phone.trim() || !address.trim()) {
      alert('Mohon isi Formulir Identitas & Alamat Pengiriman di Batam.');
      return;
    }

    const uniqueId = `DSC-${Math.floor(10000 + Math.random() * 90000)}-BTM`;
    const trackingNo = `TRK-DATASCRIP-${Math.floor(3000 + Math.random() * 6000)}`;

    const newOrderCreated: Order = {
      id: uniqueId,
      customer: { name, phone, email: email || 'pelanggan@example.com', address, distric: district },
      items: [...cartItems],
      totalAmount: totalAmount,
      orderDate: new Date().toISOString(),
      paymentStatus: paymentProofAttached ? 'Menunggu Verifikasi' : 'Belum Bayar',
      shippingStatus: 'Diterima Admin',
      trackingNumber: trackingNo,
      shippingNote: 'Pesanan baru diterima admin logistik PT. Datascrip Indonesia Cabang Batam. Menunggu konfirmasi kelengkapan transfer.'
    };

    setCreatedOrder(newOrderCreated);
    setInvoiceId(uniqueId);
    onCompleteCheckout(newOrderCreated);
    setCheckoutStep('success');
  };

  // Pre-composing elegant Whatsapp message summary
  const getWAUrl = () => {
    if (!createdOrder) return '#';
    const itemsList = createdOrder.items.map((it) => `- ${it.product.name} (x${it.quantity} ${it.product.unitType.split(' ')[0]})`).join('\n');
    const transferMsg = paymentProofAttached ? 'SAYA SUDAH TRANSFER PEMBAYARAN KE REKENING OCBC' : 'SAYA AKAN SEGERA TRANSFER PEMBAYARAN KE REKENING OCBC';
    
    const waText = `Halo Admin PT. Datascrip Indonesia (Batam),\n\nSaya telah membuat pesanan online di Portal Distributor. Berikut rinciannya:\n\n*ID INVOICE:* ${createdOrder.id}\n*Nama Pelanggan:* ${createdOrder.customer.name}\n*No. HP/WA:* ${createdOrder.customer.phone}\n*Alamat Kirim:* ${createdOrder.customer.address}, Kec. ${createdOrder.customer.distric}\n\n*DAFTAR PESANAN:*\n${itemsList}\n\n*TOTAL PEMBAYARAN:* ${formatIDR(createdOrder.totalAmount)}\n*Metode Pembayaran:* Transfer Bank OCBC (Rekening: ${COMPANY_PROFILE.bankAccount.accountNumber})\n*Status:* ${transferMsg}\n\nMohon bantu verifikasi pembayaran dan proses pengiriman ke alamat saya. Terima kasih!`;
    
    const cleanNum = COMPANY_PROFILE.whatsapp.replace(/[^0-9]/g, '');
    return `https://wa.me/${cleanNum}?text=${encodeURIComponent(waText)}`;
  };

  const resetFormAndProgress = () => {
    setCheckoutStep('cart');
    setPaymentProofAttached(false);
    setCreatedOrder(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans text-left">
      {/* Dark overlay backdrop */}
      <div 
        onClick={resetFormAndProgress} 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
      ></div>

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-lg bg-white shadow-2xl flex flex-col h-full transform transition-all duration-300">
          
          {/* Header */}
          <div className="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-blue-700 text-white rounded-tl-3xl">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5" />
              <h3 className="text-sm font-black tracking-tight">
                {checkoutStep === 'cart' && 'Keranjang Belanja'}
                {checkoutStep === 'checkout' && 'Konfirmasi Pembayaran & Alamat'}
                {checkoutStep === 'success' && 'Pesanan Berhasil Dikirim!'}
              </h3>
            </div>
            <button
              onClick={resetFormAndProgress}
              className="text-white/80 hover:text-white p-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Flow content */}
          <div className="flex-1 overflow-y-auto px-6 py-4">
            
            {checkoutStep === 'cart' && (
              /* Step 1: Browse active cart list */
              <div className="space-y-4">
                {cartItems.length === 0 ? (
                  <div className="py-24 text-center max-w-xs mx-auto space-y-4">
                    <div className="w-14 h-14 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center mx-auto border border-dashed border-blue-250">
                      <ShoppingBag className="w-6 h-6 animate-pulse" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-slate-700">Keranjang Kosong</h4>
                      <p className="text-xs text-slate-505 leading-relaxed">
                        Anda belum menambahkan satu pun kertas HVS atau buku tulis Sinar Dunia ke dalam keranjang belanja.
                      </p>
                    </div>
                    <button
                      onClick={onClose}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl cursor-pointer"
                    >
                      Jelajahi Katalog
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Item Yang Dipesan</span>
                      <span className="text-[10px] text-blue-700 font-bold font-mono">Total {cartItems.length} Produk</span>
                    </div>

                    <div className="space-y-2.5 max-h-[50vh] overflow-y-auto pr-1">
                      {cartItems.map((item) => (
                        <div
                          key={item.product.id}
                          className="flex gap-3 bg-slate-50 border border-slate-100 p-3 rounded-2xl items-center"
                        >
                          <img
                            src={item.product.imageUrl}
                            alt={item.product.name}
                            className="w-12 h-12 object-cover rounded-lg shrink-0 border border-slate-200"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1 min-w-0">
                            <span className="text-[9px] text-blue-750 font-bold uppercase font-mono">{item.product.brand}</span>
                            <h4 className="text-xs font-bold text-slate-700 truncate">{item.product.name}</h4>
                            <p className="text-[10px] text-slate-550 font-bold mt-0.5">{formatIDR(item.product.pricePerUnit)} / {item.product.unitType}</p>
                          </div>

                          {/* Controls */}
                          <div className="flex flex-col items-end gap-1.5 shrink-0 pl-2">
                            <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-white max-h-7">
                              <button
                                onClick={() => onUpdateQty(item.product.id, -1)}
                                className="px-1.5 py-0.5 hover:bg-slate-100 font-bold text-slate-500 text-xs"
                              >
                                -
                              </button>
                              <span className="px-1.5 text-[10px] font-bold font-mono text-slate-700">{item.quantity}</span>
                              <button
                                onClick={() => onUpdateQty(item.product.id, 1)}
                                className="px-1.5 py-0.5 hover:bg-slate-100 font-bold text-slate-500 text-xs"
                              >
                                +
                              </button>
                            </div>

                            <button
                              onClick={() => onRemoveItem(item.product.id)}
                              className="text-red-500 hover:text-red-700 font-semibold text-[10px] flex items-center gap-0.5"
                            >
                              <Trash2 className="w-3 h-3" /> Hapus
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Total overview & bank info reminder */}
                    <div className="pt-4 border-t border-slate-100 space-y-3">
                      <div className="flex justify-between items-baseline">
                        <span className="text-xs font-bold text-slate-500">Estimasi Tagihan:</span>
                        <span className="text-xl font-black text-blue-950 font-mono tracking-tight">{formatIDR(totalAmount)}</span>
                      </div>

                      <div className="bg-amber-50 rounded-2xl p-3 border border-amber-100 text-[11px] text-amber-800 space-y-1">
                        <span className="font-bold">Info Pengiriman Batam:</span>
                        <p className="text-amber-700">
                          - Gratis pengiriman untuk pembelanjaan minimal 3 Karton Kertas ke seluruh area Batam.<br />
                          - Waktu pengiriman standar: 1–2 hari kerja setelah verifikasi transfer disetujui.
                        </p>
                      </div>

                      <button
                        onClick={() => setCheckoutStep('checkout')}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-3.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 hover:scale-[1.01]"
                      >
                        Lanjutkan Isi Alamat & Pembayaran
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {checkoutStep === 'checkout' && (
              /* Step 2: Customer Identity Form + Bank Account Details */
              <form onSubmit={handleCheckoutProcess} className="space-y-4">
                
                {/* Bank Account Information widget */}
                <div className="bg-slate-950 text-white p-4.5 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-white/10">
                    <Landmark className="w-5 h-5 text-blue-400" />
                    <span className="text-xs font-black uppercase tracking-wider">Rekening Tujuan Pembayaran Resmi</span>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between items-baseline">
                      <span className="text-slate-400">Nama Bank:</span>
                      <span className="font-bold text-slate-100">{COMPANY_PROFILE.bankAccount.bankName}</span>
                    </div>

                    <div className="flex justify-between items-center bg-white/5 py-1.5 px-2.5 rounded-lg border border-white/5">
                      <span className="text-slate-400">No. Rekening:</span>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold font-mono text-blue-300 text-sm tracking-wide">
                          {COMPANY_PROFILE.bankAccount.accountNumber}
                        </span>
                        <button
                          type="button"
                          onClick={handleCopyNum}
                          className="bg-white/10 hover:bg-white/20 p-1 rounded-md text-slate-200 transition-colors"
                          title="Salin Nomor Rekening"
                        >
                          <ClipboardCopy className={`w-3.5 h-3.5 ${copiedAcct ? 'text-emerald-400 font-bold' : ''}`} />
                        </button>
                      </div>
                    </div>

                    <div className="flex justify-between items-baseline">
                      <span className="text-slate-400">Atas Nama (A/N):</span>
                      <span className="font-extrabold text-blue-300">{COMPANY_PROFILE.bankAccount.accountHolder}</span>
                    </div>
                  </div>

                  <div className="pt-1.5 border-t border-white/10 flex justify-between items-center text-[10px] text-slate-400">
                    <span>Setelah bayar, centang kotak bukti bayar berikut:</span>
                    <label className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-2 py-1 rounded-md font-bold cursor-pointer transition-colors">
                      <input
                        type="checkbox"
                        checked={paymentProofAttached}
                        onChange={(e) => setPaymentProofAttached(e.target.checked)}
                        className="rounded border-none accent-blue-500 focus:ring-0 cursor-pointer"
                      />
                      <span>Sudah Bayar / Ada Bukti</span>
                    </label>
                  </div>
                </div>

                {/* Shipping Identity Form */}
                <div className="space-y-3 bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-1">
                    Formulir Alamat Pengiriman Batam & PIC Hubungan:
                  </span>

                  <div className="space-y-3 text-xs text-slate-800">
                    <div className="space-y-0.5">
                      <label className="text-[10px] font-bold text-slate-505">Nama Penerima / Perusahaan:</label>
                      <div className="relative">
                        <User className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                        <input
                          type="text"
                          required
                          placeholder="Nama lengkap atau nama sekolah/perusahaan"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs focus:ring-1 focus:ring-blue-500 outline-none h-9 text-slate-755"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-0.5">
                        <label className="text-[10px] font-bold text-slate-505">No. WhatsApp Aktif:</label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                          <input
                            type="tel"
                            required
                            placeholder="Contoh: 0852-xxxx-xxxx"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs focus:ring-1 focus:ring-blue-505 outline-none h-9 text-slate-755"
                          />
                        </div>
                      </div>

                      <div className="space-y-0.5">
                        <label className="text-[10px] font-bold text-slate-550">Email Bisnis (Opsional):</label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                          <input
                            type="email"
                            placeholder="nama@alamat.com"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs focus:ring-1 focus:ring-blue-505 outline-none h-9 text-slate-755"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-0.5">
                      <label className="text-[10px] font-bold text-slate-550">Kecamatan Pengiriman Batam:</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                        <select
                          value={district}
                          onChange={(e) => setDistrict(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs focus:ring-1 focus:ring-blue-505 outline-none h-9 text-slate-755"
                        >
                          {BATAM_DISTRICTS.map((dst) => (
                            <option key={dst} value={dst}>{dst}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-0.5">
                      <label className="text-[10px] font-bold text-slate-550">Alamat Lengkap Jalan / Ruko / Kelurahan:</label>
                      <textarea
                        required
                        rows={2}
                        placeholder="Nama ruko, jalan, blok, RT/RW, nomor gedung, patokan dekat..."
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-xl p-2.5 text-xs focus:ring-1 focus:ring-blue-505 outline-none text-slate-755"
                      />
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 border-t border-slate-100 flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs py-3 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 hover:scale-[1.01]"
                  >
                    Kirim & Tempatkan Pesanan
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setCheckoutStep('cart')}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-3 px-4 rounded-xl transition-all cursor-pointer"
                  >
                    Kembali
                  </button>
                </div>
              </form>
            )}

            {checkoutStep === 'success' && createdOrder && (
              /* Step 3: Success Notification with direct confirmation triggers */
              <div className="text-center py-6 space-y-5 animate-in fade-in duration-300">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto border border-emerald-100">
                  <CheckCircle2 className="w-10 h-10" />
                </div>

                <div className="space-y-1.5">
                  <h4 className="text-base font-black text-slate-800">Transaksi Berhasil Direkam!</h4>
                  <p className="text-xs text-slate-500">Kode Invoice Pesanan Anda:</p>
                  <span className="inline-block bg-slate-100 border border-slate-200 text-slate-800 font-bold px-4 py-1.5 rounded-xl font-mono text-sm tracking-wider">
                    {invoiceId}
                  </span>
                </div>

                <div className="bg-slate-50 p-4.5 rounded-2xl border border-slate-100 text-xs text-gray-600 text-left space-y-2">
                  <span className="font-bold text-slate-700 block text-center pb-2 border-b border-slate-200">
                    Satu Langkah Terakhir!
                  </span>
                  <p className="leading-relaxed">
                    Untuk mempercepat pengesahan berkas oleh administrasi <strong>PT. Datascrip Indonesia</strong>, mohon kirimkan konfirmasi rincian pesanan dan bukti bayar langsung melalui WhatsApp resmi kami.
                  </p>
                  <p className="text-[11px] text-blue-700 font-semibold bg-blue-50/50 p-2 rounded-lg border border-blue-100/50">
                    Alamat Distribusi: {createdOrder.customer.address}, {createdOrder.customer.distric} Batam.
                  </p>
                </div>

                <div className="pt-3 flex flex-col gap-2">
                  <a
                    href={getWAUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs py-3.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 hover:scale-[1.01]"
                  >
                    <Send className="w-4 h-4" />
                    Kirim Konfirmasi Ke Admin WhatsApp
                  </a>

                  <button
                    onClick={resetFormAndProgress}
                    className="w-full bg-slate-800 hover:bg-slate-750 text-white font-bold text-xs py-3 rounded-xl transition-all cursor-pointer"
                  >
                    Selesai & Tutup Belanja
                  </button>
                </div>
              </div>
            )}

          </div>

          {/* Footer stats or reminders */}
          {checkoutStep !== 'success' && (
            <div className="px-6 py-4.5 border-t border-slate-100 bg-slate-50/70 flex justify-between items-center text-[10px] text-slate-500">
              <span className="flex items-center gap-1 font-semibold">
                <Landmark className="w-3.5 h-3.5 text-blue-600" /> OCBC Indonesia Authorized
              </span>
              <span>PT. Datascrip Batam Hub • 2026</span>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
