import { Warehouse, HeartHandshake, ShieldCheck, Truck, Sparkles } from 'lucide-react';

interface HeroProps {
  onExploreCatalog: () => void;
  onTrackOrder: () => void;
}

export default function Hero({ onExploreCatalog, onTrackOrder }: HeroProps) {
  return (
    <section className="bg-slate-900 text-white overflow-hidden py-12 px-4 sm:px-6 lg:px-8 relative font-sans rounded-3xl mb-8 shadow-xl">
      {/* Visual background patterns */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl -ml-24 -mb-24 pointer-events-none"></div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Slogan and Branding Statement */}
          <div className="lg:col-span-7 space-y-5 text-left">
            <div className="inline-flex items-center gap-2 bg-blue-500/20 text-blue-300 font-bold px-3 py-1.5 rounded-full text-xs uppercase tracking-wider border border-blue-400/20 font-mono">
              <Sparkles className="w-3.5 h-3.5 text-blue-400 animate-spin" />
              Layanan Distribusi Batam Utama
            </div>
            
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black font-sans leading-tight tracking-tight">
              Penyedia Kertas HVS & <br />
              <span className="text-blue-400">Buku Tulis Resmi</span> di Batam
            </h2>
            
            <p className="text-sm sm:text-base text-slate-300 max-w-xl leading-relaxed">
              Selamat datang di portal resmi <strong>PT. DATASCRIP INDONESIA</strong>. Kami adalah mitra distribusi eksklusif kertas HVS kualitas tinggi dan buku tulis bergaris premium di Batam Kepulauan Riau. Menyediakan pasokan prima langsung untuk perkantoran, instansi, swasta, sekolah, dan grosir alat tulis dengan jaminan keaslian merk.
            </p>

            {/* Brands Logo Strip */}
            <div className="space-y-2.5 pt-2">
              <span className="text-[10px] uppercase tracking-widest font-extrabold text-slate-400 block">
                Merek Utama Terdistribusi:
              </span>
              <div className="flex flex-wrap gap-2.5">
                {[
                  { name: 'Sinar Dunia', slogan: 'SiDU Best Seller', color: 'border-cyan-500/30 text-cyan-300' },
                  { name: 'PaperOne', slogan: 'ProDigi Technology', color: 'border-blue-500/30 text-blue-300' },
                  { name: 'e-Paper', slogan: 'Eco-Friendly White', color: 'border-amber-500/30 text-amber-300' }
                ].map((brand, idx) => (
                  <div
                    key={idx}
                    className={`px-3 py-1.5 rounded-xl border bg-white/5 flex flex-col ${brand.color}`}
                  >
                    <span className="text-xs font-black">{brand.name}</span>
                    <span className="text-[8px] font-mono tracking-wider opacity-70 uppercase">{brand.slogan}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap gap-3.5 pt-4">
              <button
                onClick={onExploreCatalog}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm px-6 py-3.5 rounded-xl transition-all hover:scale-[1.01] shadow-lg shadow-blue-600/30 cursor-pointer flex items-center gap-2 border border-blue-500"
              >
                Lihat Katalog & Pesan Online
              </button>
              <button
                onClick={onTrackOrder}
                className="bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs sm:text-sm px-6 py-3.5 rounded-xl transition-all border border-slate-700 hover:text-white cursor-pointer"
              >
                Lacak Status Pengiriman
              </button>
            </div>
          </div>

          {/* Quick Stats Grid & Info cards */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-left transition-all hover:bg-white/10">
              <div className="bg-blue-500/20 text-blue-400 w-10 h-10 rounded-xl flex items-center justify-center mb-3">
                <Warehouse className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-slate-100 font-sans">Gudang Utama Batam</h4>
              <p className="text-xs text-slate-400 mt-1">Stok ribuan karton selalu siap saji untuk pengiriman instan.</p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-left transition-all hover:bg-white/10">
              <div className="bg-teal-500/20 text-teal-400 w-10 h-10 rounded-xl flex items-center justify-center mb-3">
                <Truck className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-slate-100 font-sans">12 Kecamatan Tercover</h4>
              <p className="text-xs text-slate-400 mt-1">Pengiriman armada mandiri mencakup seluruh kecamatan Batam.</p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-left transition-all hover:bg-white/10">
              <div className="bg-amber-500/20 text-amber-400 w-10 h-10 rounded-xl flex items-center justify-center mb-3">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-slate-100 font-sans">Pasti Keaslian 100%</h4>
              <p className="text-xs text-slate-400 mt-1">Garansi pabrik dari APP Sinar Mas dan APRIL Group.</p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-left transition-all hover:bg-white/10">
              <div className="bg-pink-500/20 text-pink-400 w-10 h-10 rounded-xl flex items-center justify-center mb-3">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-slate-100 font-sans">Pemesanan Mudah</h4>
              <p className="text-xs text-slate-400 mt-1">Pilih gramatur dan ukuran, bayar aman, lacak langsung.</p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
